/sbin/ldconfig

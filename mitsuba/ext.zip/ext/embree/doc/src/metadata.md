% Embree: High Performance Ray Tracing Kernels <EMBREE_VERSION>
% Intel Corporation

